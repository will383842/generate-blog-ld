<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Ajouter author_id et image_id à articles
        Schema::table('articles', function (Blueprint $table) {
            if (!Schema::hasColumn('articles', 'author_id')) {
                $table->foreignId('author_id')->nullable()->after('template_id')->constrained()->onDelete('set null');
            }
            if (!Schema::hasColumn('articles', 'image_id')) {
                $table->unsignedBigInteger('image_id')->nullable()->after('author_id');
            }
            if (!Schema::hasColumn('articles', 'scheduled_at')) {
                $table->timestamp('scheduled_at')->nullable()->after('published_at');
            }
            if (!Schema::hasColumn('articles', 'indexed_at')) {
                $table->timestamp('indexed_at')->nullable()->after('scheduled_at');
            }
        });

        // Ajouter timezone_id à countries si manquant
        Schema::table('countries', function (Blueprint $table) {
            if (!Schema::hasColumn('countries', 'timezone_default')) {
                $table->string('timezone_default', 50)->nullable()->after('phone_code');
            }
        });

        // Ajouter platform_id à expat_domains si manquant (pour séparation SOS/Ulixai)
        Schema::table('expat_domains', function (Blueprint $table) {
            if (!Schema::hasColumn('expat_domains', 'platform_id')) {
                $table->foreignId('platform_id')->nullable()->after('id')->constrained()->onDelete('cascade');
            }
        });
    }

    public function down(): void
    {
        Schema::table('articles', function (Blueprint $table) {
            $table->dropForeign(['author_id']);
            $table->dropColumn(['author_id', 'image_id', 'scheduled_at', 'indexed_at']);
        });

        Schema::table('countries', function (Blueprint $table) {
            $table->dropColumn('timezone_default');
        });

        Schema::table('expat_domains', function (Blueprint $table) {
            $table->dropForeign(['platform_id']);
            $table->dropColumn('platform_id');
        });
    }
};
