<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Article extends Model
{
    use HasFactory;

    protected $fillable = [
        'uuid',
        'platform_id',
        'theme_id',
        'template_id',
        'author_id',
        'image_id',
        'country_code',
        'provider_type_id',
        'specialty_id',
        'service_id',
        'domain_id',
        'type',
        'status',
        'word_count',
        'quality_score',
        'generation_cost',
        'translation_cost',
        'total_cost',
        'generated_at',
        'published_at',
        'scheduled_at',
        'indexed_at',
    ];

    protected $casts = [
        'word_count' => 'integer',
        'quality_score' => 'integer',
        'generation_cost' => 'float',
        'translation_cost' => 'float',
        'total_cost' => 'float',
        'generated_at' => 'datetime',
        'published_at' => 'datetime',
        'scheduled_at' => 'datetime',
        'indexed_at' => 'datetime',
    ];

    // =========================================================================
    // CONSTANTES STATUS
    // =========================================================================

    const STATUS_DRAFT = 'draft';
    const STATUS_GENERATING = 'generating';
    const STATUS_GENERATED = 'generated';
    const STATUS_TRANSLATING = 'translating';
    const STATUS_TRANSLATED = 'translated';
    const STATUS_SCHEDULED = 'scheduled';
    const STATUS_PUBLISHED = 'published';
    const STATUS_FAILED = 'failed';

    const TYPE_ARTICLE = 'article';
    const TYPE_LANDING = 'landing';
    const TYPE_COMPARATIVE = 'comparative';

    // =========================================================================
    // RELATIONS
    // =========================================================================

    public function platform(): BelongsTo
    {
        return $this->belongsTo(Platform::class);
    }

    public function theme(): BelongsTo
    {
        return $this->belongsTo(Theme::class);
    }

    public function template(): BelongsTo
    {
        return $this->belongsTo(Template::class);
    }

    public function author(): BelongsTo
    {
        return $this->belongsTo(Author::class);
    }

    public function image(): BelongsTo
    {
        return $this->belongsTo(ImageLibrary::class, 'image_id');
    }

    public function country(): BelongsTo
    {
        return $this->belongsTo(Country::class, 'country_code', 'code');
    }

    public function providerType(): BelongsTo
    {
        return $this->belongsTo(ProviderType::class);
    }

    public function specialty(): BelongsTo
    {
        return $this->belongsTo(LawyerSpecialty::class, 'specialty_id');
    }

    public function service(): BelongsTo
    {
        return $this->belongsTo(UlixaiService::class, 'service_id');
    }

    public function domain(): BelongsTo
    {
        return $this->belongsTo(ExpatDomain::class, 'domain_id');
    }

    public function translations(): HasMany
    {
        return $this->hasMany(ArticleTranslation::class);
    }

    public function faqs(): HasMany
    {
        return $this->hasMany(ArticleFaq::class);
    }

    public function internalLinks(): HasMany
    {
        return $this->hasMany(InternalLink::class);
    }

    public function externalLinks(): HasMany
    {
        return $this->hasMany(ExternalLink::class);
    }

    public function sources(): HasMany
    {
        return $this->hasMany(ArticleSource::class);
    }

    public function index(): HasOne
    {
        return $this->hasOne(ArticleIndex::class);
    }

    public function versions(): HasMany
    {
        return $this->hasMany(ArticleVersion::class);
    }

    public function exports(): HasMany
    {
        return $this->hasMany(ArticleExport::class);
    }

    public function publicationQueue(): HasMany
    {
        return $this->hasMany(PublicationQueue::class);
    }

    public function generationLogs(): HasMany
    {
        return $this->hasMany(GenerationLog::class);
    }

    // =========================================================================
    // SCOPES
    // =========================================================================

    public function scopePublished($query)
    {
        return $query->where('status', self::STATUS_PUBLISHED);
    }

    public function scopeDraft($query)
    {
        return $query->where('status', self::STATUS_DRAFT);
    }

    public function scopeOfType($query, string $type)
    {
        return $query->where('type', $type);
    }

    public function scopeForPlatform($query, int $platformId)
    {
        return $query->where('platform_id', $platformId);
    }

    public function scopeForCountry($query, string $countryCode)
    {
        return $query->where('country_code', $countryCode);
    }

    public function scopeForTheme($query, int $themeId)
    {
        return $query->where('theme_id', $themeId);
    }

    public function scopeRecent($query, int $days = 7)
    {
        return $query->where('created_at', '>=', now()->subDays($days));
    }

    // =========================================================================
    // HELPERS
    // =========================================================================

    /**
     * Obtenir la traduction dans une langue
     */
    public function getTranslation(string $languageCode): ?ArticleTranslation
    {
        return $this->translations->where('language_code', $languageCode)->first();
    }

    /**
     * Obtenir le titre traduit
     */
    public function getTitle(string $languageCode = 'fr'): ?string
    {
        return $this->getTranslation($languageCode)?->title;
    }

    /**
     * Obtenir le slug traduit
     */
    public function getSlug(string $languageCode = 'fr'): ?string
    {
        return $this->getTranslation($languageCode)?->slug;
    }

    /**
     * Obtenir les FAQ dans une langue
     */
    public function getFaqs(string $languageCode = 'fr'): \Illuminate\Support\Collection
    {
        return $this->faqs->where('language_code', $languageCode)->sortBy('sort_order');
    }

    /**
     * Vérifier si l'article est publié
     */
    public function isPublished(): bool
    {
        return $this->status === self::STATUS_PUBLISHED;
    }

    /**
     * Vérifier si toutes les traductions sont complètes
     */
    public function hasAllTranslations(array $languages = ['fr', 'en', 'de', 'es', 'pt', 'ru', 'zh', 'ar', 'hi']): bool
    {
        $existingLanguages = $this->translations->pluck('language_code')->toArray();
        return empty(array_diff($languages, $existingLanguages));
    }

    /**
     * Obtenir les langues manquantes
     */
    public function getMissingLanguages(array $languages = ['fr', 'en', 'de', 'es', 'pt', 'ru', 'zh', 'ar', 'hi']): array
    {
        $existingLanguages = $this->translations->pluck('language_code')->toArray();
        return array_values(array_diff($languages, $existingLanguages));
    }

    /**
     * Calculer le coût total
     */
    public function calculateTotalCost(): float
    {
        $this->total_cost = $this->generation_cost + $this->translation_cost;
        $this->save();
        return $this->total_cost;
    }

    /**
     * Obtenir l'URL publique
     */
    public function getPublicUrl(string $languageCode = 'fr'): string
    {
        $baseUrl = $this->platform?->domain ?? 'https://sos-expat.com';
        $slug = $this->getSlug($languageCode);
        
        return "{$baseUrl}/{$languageCode}/articles/{$slug}";
    }
}
