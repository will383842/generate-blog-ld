<?php

namespace App\Models;

use App\Traits\HasTranslations;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ExpatDomain extends Model
{
    use HasFactory, HasTranslations;

    protected $fillable = [
        'slug',
        'platform_id',
        'name_fr',
        'name_en',
        'icon',
        'color',
        'is_active',
        'sort_order',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'sort_order' => 'integer',
    ];

    // =========================================================================
    // RELATIONS
    // =========================================================================

    public function translations(): HasMany
    {
        return $this->hasMany(ExpatDomainTranslation::class);
    }

    public function platform(): BelongsTo
    {
        return $this->belongsTo(Platform::class);
    }

    public function articles(): HasMany
    {
        return $this->hasMany(Article::class, 'domain_id');
    }

    // =========================================================================
    // SCOPES
    // =========================================================================

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeOrdered($query)
    {
        return $query->orderBy('sort_order');
    }

    public function scopeForPlatform($query, int $platformId)
    {
        return $query->where('platform_id', $platformId);
    }

    public function scopeForSosExpat($query)
    {
        return $query->whereHas('platform', fn($q) => $q->where('slug', 'sos-expat'));
    }

    public function scopeForUlixai($query)
    {
        return $query->whereHas('platform', fn($q) => $q->where('slug', 'ulixai'));
    }

    // =========================================================================
    // HELPERS
    // =========================================================================

    public function getName(string $languageCode = 'fr'): string
    {
        return $this->translated('name', $languageCode, $this->name_fr);
    }

    public function getSlug(string $languageCode = 'fr'): string
    {
        return $this->translated('slug', $languageCode, $this->slug);
    }

    public function getDescription(string $languageCode = 'fr'): ?string
    {
        return $this->translated('description', $languageCode);
    }

    public function isSosExpat(): bool
    {
        return $this->platform?->slug === 'sos-expat';
    }

    public function isUlixai(): bool
    {
        return $this->platform?->slug === 'ulixai';
    }
}
