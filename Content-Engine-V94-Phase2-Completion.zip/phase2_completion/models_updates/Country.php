<?php

namespace App\Models;

use App\Traits\HasTranslations;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Country extends Model
{
    use HasFactory, HasTranslations;

    protected $fillable = [
        'code',
        'code_iso3',
        'name',
        'name_local',
        'region_id',
        'currency_id',
        'phone_code',
        'timezone_default',
        'flag_emoji',
        'flag_url',
        'population',
        'expat_count',
        'is_active',
        'sort_order',
    ];

    protected $casts = [
        'population' => 'integer',
        'expat_count' => 'integer',
        'is_active' => 'boolean',
        'sort_order' => 'integer',
    ];

    // =========================================================================
    // RELATIONS
    // =========================================================================

    public function translations(): HasMany
    {
        return $this->hasMany(CountryTranslation::class);
    }

    public function region(): BelongsTo
    {
        return $this->belongsTo(Region::class);
    }

    public function currency(): BelongsTo
    {
        return $this->belongsTo(Currency::class);
    }

    public function languages(): BelongsToMany
    {
        return $this->belongsToMany(Language::class, 'country_language')
                    ->withPivot(['is_official', 'percentage'])
                    ->withTimestamps();
    }

    public function articles(): HasMany
    {
        return $this->hasMany(Article::class, 'country_code', 'code');
    }

    // =========================================================================
    // SCOPES
    // =========================================================================

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeOrdered($query)
    {
        return $query->orderBy('sort_order')->orderBy('name');
    }

    public function scopeInRegion($query, int $regionId)
    {
        return $query->where('region_id', $regionId);
    }

    // =========================================================================
    // HELPERS - TRADUCTIONS
    // =========================================================================

    /**
     * Obtenir le nom traduit
     */
    public function getName(string $languageCode = 'fr'): string
    {
        return $this->translated('name', $languageCode, $this->name);
    }

    /**
     * Obtenir le nom avec préposition (en France, au Japon, aux États-Unis)
     */
    public function getNameIn(string $languageCode = 'fr'): string
    {
        return $this->translated('name_in', $languageCode, "en {$this->getName($languageCode)}");
    }

    /**
     * Obtenir le nom avec préposition "de/d'/du/des"
     */
    public function getNameFrom(string $languageCode = 'fr'): string
    {
        return $this->translated('name_from', $languageCode, "de {$this->getName($languageCode)}");
    }

    /**
     * Obtenir l'adjectif (français, japonais)
     */
    public function getAdjective(string $languageCode = 'fr', bool $plural = false, bool $feminine = false): string
    {
        $translation = $this->getTranslation($languageCode);
        
        if (!$translation) {
            return '';
        }

        if ($feminine && $plural && $translation->adjective_feminine_plural) {
            return $translation->adjective_feminine_plural;
        }
        if ($feminine && $translation->adjective_feminine) {
            return $translation->adjective_feminine;
        }
        if ($plural && $translation->adjective_plural) {
            return $translation->adjective_plural;
        }
        
        return $translation->adjective ?? '';
    }

    /**
     * Obtenir le slug traduit
     */
    public function getSlug(string $languageCode = 'fr'): string
    {
        return $this->translated('slug', $languageCode, strtolower($this->code));
    }

    /**
     * Obtenir le fuseau horaire par défaut
     */
    public function getTimezone(): string
    {
        return $this->timezone_default ?? 'UTC';
    }
}
